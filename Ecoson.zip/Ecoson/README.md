<!--
SPDX-FileCopyrightText: 2026 Lutitious <notlutitious@gmail.com>

SPDX-License-Identifier: CC0-1.0
-->

Ecoson
---
I didn't create it fully from scratch, this is an edit of Fluent Dark theme.
Thanks for downloading, love you! 😊


## Preview
![Ecoson Theme Previews](../../themes/theme-previews.mp4)

## License
```
MIT License

Copyright (c) 2026 Ecoson
Copyright (c) 2022 JoeGaming
Copyright (c) 2022 Witali Hirsch
Copyright (c) 2020 Microsoft Corporation

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```
